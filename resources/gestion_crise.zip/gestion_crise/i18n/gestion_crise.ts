<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1" language="fr_FR" sourcelanguage="fr_FR">
<context>
    <name>FullProgressSearchWorker</name>
    <message>
        <location filename="../Gestion_crise.py" line="147" />
        <source>Test du lecteur %1…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="188" />
        <source>Test des serveurs DDT…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="198" />
        <source>Recherche du réseau interne…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="218" />
        <source>Analyse terminée.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>FullSearchWorker</name>
    <message>
        <location filename="../Gestion_crise.py" line="337" />
        <source>Test du lecteur %1…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="376" />
        <source>Disque externe détecté.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="385" />
        <source>Test des serveurs…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="395" />
        <source>Recherche du réseau interne…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="419" />
        <source>Analyse terminée.</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>Gestion_crise</name>
    <message>
        <location filename="../Gestion_crise.py" line="685" />
        <source>&amp;Gestion de crise</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="797" />
        <source>Lancement projet gestion de crise</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="800" />
        <source>Démonter le disque externe</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="804" />
        <source>Configurer les partages réseau</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="820" />
        <source>Recompiler les ressources (resources.qrc)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="832" />
        <source>Activer le mode débogage</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="844" />
        <source>Aide / Manuel d'utilisation</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="981" />
        <source>Aide - Gestion_crise</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="903" />
        <source>Aucun fichier d'aide n'a été trouvé dans le dossier 'help'.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="914" />
        <source>Impossible de lire le fichier d'aide : %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="994" />
        <source>Fermer</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="3001" />
        <source>Erreur</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1248" />
        <source>Aucun disque spécifié.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1256" />
        <source>Le disque %1 n'existe pas.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1342" />
        <source>Montage terminé</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1342" />
        <source>[SUCCÈS] Montage terminé depuis %1

%2</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1417" />
        <source>Attention : ces lecteurs existent encore : %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1424" />
        <source>Impossible de finaliser le démontage.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1428" />
        <source>Démontage incomplet</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1435" />
        <source>Tous les montages ont été correctement démontés.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1442" />
        <source>Serveurs DDT indisponibles.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1479" />
        <source>Résultat</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1453" />
        <source>Réseau interne</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1453" />
        <source>Voulez-vous remonter le réseau interne DDT ?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1489" />
        <source>Information</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1489" />
        <source>Script batch introuvable : %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1639" />
        <source>Ouverture de la configuration…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1645" />
        <source>Configuration des partages réseau</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1705" />
        <source>🔴</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1697" />
        <source>🟢</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1701" />
        <source>🟠</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1730" />
        <source>✖</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1868" />
        <source>Aucun partage</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1868" />
        <source>Aucun lecteur réseau valide n'a été détecté via la commande net use.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1884" />
        <source>Les partages suivants ont été trouvés :

%1

Voulez-vous les importer ?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1890" />
        <source>Import des partages Windows</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1903" />
        <source>Importation des partages Windows en cours…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2039" />
        <source>Réinitialiser</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1926" />
        <source>Voulez-vous restaurer les partages par défaut ?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1936" />
        <source>Réinitialisation des partages en cours…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1956" />
        <source>Réinitialisation terminée</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1956" />
        <source>Les partages ont été restaurés.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1967" />
        <source>Enregistrement de la configuration en cours…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1990" />
        <source>Partages enregistrés</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="1990" />
        <source>La configuration a bien été sauvegardée.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2047" />
        <source>Annuler</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2004" />
        <source>Des modifications n'ont pas été enregistrées.
Voulez-vous vraiment quitter ?</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2027" />
        <source>+ Ajouter</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2031" />
        <source>Importer partages Windows</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2035" />
        <source>Tester</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2043" />
        <source>Enregistrer</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2483" />
        <source>Connexion disque externe (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2386" />
        <source>Montage déjà effectué</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2386" />
        <source>Un disque externe est déjà monté.
Veuillez le démonter avant de relancer l’outil.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2421" />
        <source>Recherche du disque externe…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2458" />
        <source>Montage disque externe impossible</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2458" />
        <source>Le disque externe a été détecté (%1) mais le montage des lecteurs (%2) a échoué.

Vérifiez la présence des dossiers à la racine du disque, puis réessayez.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2503" />
        <source>Connexion réseau (%1)</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2558" />
        <source>Aucune connexion disponible</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2558" />
        <source>Aucun disque externe.
Aucun serveur DDT ne répond.
Aucun lecteur réseau accessible.

Impossible de continuer.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2676" />
        <source>⚠️ Partages réseau inaccessibles : %1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2731" />
        <source>Impossible de copier le projet modèle embarqué :
%1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2760" />
        <source>Exercice gestion de crise</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2760" />
        <source>Nom de l'exercice :</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2780" />
        <source>Gestion de crise</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2780" />
        <source>Nom de la crise :</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2818" />
        <source>Commande inutile : </source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2818" />
        <source>Les couches sont déjà présentes.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2831" />
        <source>Création impossible</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2831" />
        <source>Le projet doit être enregistré avant la création des couches Evenements.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2911" />
        <source>Erreur création shapefile</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="2985" />
        <source>Compilation des ressources…</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="3001" />
        <source>resources.qrc introuvable :
%1</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="3048" />
        <source>Compilation réussie</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="3048" />
        <source>resources.qrc → resources.py généré.</source>
        <translation type="unfinished" />
    </message>
    <message>
        <location filename="../Gestion_crise.py" line="3054" />
        <source>Erreur compilation</source>
        <translation type="unfinished" />
    </message>
</context>
<context>
    <name>ThrobberProgressDialog</name>
    <message>
        <location filename="../Gestion_crise.py" line="528" />
        <source>Analyse en cours…</source>
        <translation type="unfinished" />
    </message>
</context>
</TS>